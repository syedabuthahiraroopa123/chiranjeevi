const form = document.querySelector('#form')
const username=document.querySelector('#username');
const password=document.querySelector('#password');
const email=document.querySelector('#email');
const phonenumber=document.querySelector('#phonenumber');

form.addEventListener('submit',(e)=>{
    
    if(!validateInputs()){
        e.preventDefault();
    }
})

function validateInputs(){
    const usernameval = username.value.trim() ;
    const passwordval = password.value.trim() ;
    const emailval = email.value.trim() ;
    const phonenumberval = phonenumber.value.trim();
    let sucess=true
    
    if(usernameval === ''){
        sucess=false;
        seterror(username,"Required")
    }
    else{
        setsucess(username)
    }

    if(emailval === ''){
        sucess=false;
        seterror(email,"Email is required")
    
    }
    else{
        setsucess(email)
    }
    
    if(passwordval === ''){
        sucess=false;
        seterror(password,"password required")

    }
    else if(passwordval.length <8){
        sucess=false;
        seterror(password,"Password must be max 8 characters")
    }
    else{
        setsucess(password)
    }

    return sucess
}
function seterror(element,message){
    const inputgrp = element.parentElement;
    const errorelement = inputgrp.querySelector('.error')

    errorelement.innerText = message;
    inputgrp.classList.add('error')
    inputgrp.classList.remove('sucess')
}

function setsucess(element){
    const inputgrp = element.parentElement;
    const errorelement = inputgrp.querySelector('.error')

    errorelement.innerText = '';
    inputgrp.classList.add('sucess')
    inputgrp.classList.remove('error')
}
